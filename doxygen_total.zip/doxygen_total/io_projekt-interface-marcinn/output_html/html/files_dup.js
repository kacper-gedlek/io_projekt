var files_dup =
[
    [ "node_modules", "dir_acd06b18086a0dd2ae699b1e0b775be8.html", "dir_acd06b18086a0dd2ae699b1e0b775be8" ],
    [ "src", "dir_68267d1309a1af8e8297ef4c3efbcdba.html", "dir_68267d1309a1af8e8297ef4c3efbcdba" ],
    [ "main.py", "main_8py.html", "main_8py" ],
    [ "rfid_reader.py", "rfid__reader_8py.html", "rfid__reader_8py" ]
];