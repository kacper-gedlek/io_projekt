var indexSectionsWithContent =
{
  0: "123abcdefghijklmnopqrstuvwxz⚡📊🙏🚄🦮",
  1: "mr",
  2: "acdlmrt",
  3: "abcefghikmnrs",
  4: "acdhklmoprstu",
  5: "123abcdefghijklmnopqrstuvwxz⚡📊🙏🚄🦮"
};

var indexSectionNames =
{
  0: "all",
  1: "namespaces",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Namespaces",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Pages"
};

