var searchData=
[
  ['📊_20benchmarks_3a_0',['📊 Benchmarks:',['../dir_e50ad3350d68b96628fd2070cabfbc61.html#autotoc_md40',1,'']]]
];
