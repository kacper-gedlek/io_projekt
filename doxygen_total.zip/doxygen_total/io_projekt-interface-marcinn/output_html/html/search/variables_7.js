var searchData=
[
  ['ostatni_5fczas_0',['ostatni_czas',['../namespacerfid__reader.html#a45f751a339e60d2ddf28166dcd308d54',1,'rfid_reader']]],
  ['ostatni_5fuid_1',['ostatni_uid',['../namespacerfid__reader.html#a7fded2a89ce6a3a3cd220d0293d2d434',1,'rfid_reader']]]
];
