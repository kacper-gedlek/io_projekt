var searchData=
[
  ['a_20source_20map_0',['a source map',['../dir_e383ee6c920e4f5c6647b8cd409a80b8.html#autotoc_md113',1,'Consuming a source map'],['../dir_e383ee6c920e4f5c6647b8cd409a80b8.html#autotoc_md114',1,'Generating a source map']]],
  ['about_1',['About',['../dir_7a583677d98b93c95bf092b149de9207.html#autotoc_md85',1,'']]],
  ['add_20chunk_2',['SourceNode.prototype.add(chunk)',['../dir_e383ee6c920e4f5c6647b8cd409a80b8.html#autotoc_md137',1,'']]],
  ['addmapping_20mapping_3',['SourceMapGenerator.prototype.addMapping(mapping)',['../dir_e383ee6c920e4f5c6647b8cd409a80b8.html#autotoc_md130',1,'']]],
  ['advanced_20globbing_4',['Advanced globbing',['../dir_7a583677d98b93c95bf092b149de9207.html#autotoc_md77',1,'']]],
  ['agent_5',['@vercel/detect-agent',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md162',1,'']]],
  ['alias_20plugin_20dynamic_20import_20vars_20pluginutils_6',['@rollup/plugin-alias, @rollup/plugin-dynamic-import-vars, @rollup/pluginutils',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md160',1,'']]],
  ['allgeneratedpositionsfor_20originalposition_7',['SourceMapConsumer.prototype.allGeneratedPositionsFor(originalPosition)',['../dir_e383ee6c920e4f5c6647b8cd409a80b8.html#autotoc_md123',1,'']]],
  ['anymatch_8',['anymatch',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md166',1,'']]],
  ['api_9',['API',['../dir_db987a62e8987a103163524e89b0126d.html#autotoc_md26',1,'API'],['../dir_7a583677d98b93c95bf092b149de9207.html#autotoc_md55',1,'API'],['../dir_ca5928ce57d942246ce529d4df3ccdc3.html#autotoc_md97',1,'API'],['../dir_c482761834072f124f8df279fc01880d.html#autotoc_md104',1,'API'],['../dir_e383ee6c920e4f5c6647b8cd409a80b8.html#autotoc_md117',1,'API'],['../dir_e383ee6c920e4f5c6647b8cd409a80b8.html#autotoc_md116',1,'With SourceMapGenerator (low level API)'],['../dir_e383ee6c920e4f5c6647b8cd409a80b8.html#autotoc_md115',1,'With SourceNode (high level API)']]],
  ['applescript_20wsl_20utils_10',['bundle-name, default-browser, default-browser-id, define-lazy-prop, is-docker, is-inside-container, is-wsl, open, run-applescript, wsl-utils',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md174',1,'']]],
  ['applysourcemap_20sourcemapconsumer_20sourcefile_20sourcemappath_11',['SourceMapGenerator.prototype.applySourceMap(sourceMapConsumer[, sourceFile[, sourceMapPath]])',['../dir_e383ee6c920e4f5c6647b8cd409a80b8.html#autotoc_md132',1,'']]],
  ['architektura_20integracji_20z_20serwerem_20moodle_12',['1. Architektura integracji z serwerem Moodle',['../baza_danych.html#moodle_sec',1,'']]],
  ['architektura_20systemu_20podział_20na_20moduły_13',['2. Architektura systemu (Podział na moduły)',['../index.html#arch_sec',1,'']]],
  ['artichokie_14',['artichokie',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md168',1,'']]],
  ['as_20literals_15',['Matching special characters as literals',['../dir_7a583677d98b93c95bf092b149de9207.html#autotoc_md81',1,'']]],
  ['assign_16',['object-assign',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md250',1,'']]],
  ['attendance_17',['Oficjalna Dokumentacja Systemu: Zero-TOUCH Attendance',['../index.html',1,'']]],
  ['author_18',['Author',['../dir_7a583677d98b93c95bf092b149de9207.html#autotoc_md86',1,'']]]
];
