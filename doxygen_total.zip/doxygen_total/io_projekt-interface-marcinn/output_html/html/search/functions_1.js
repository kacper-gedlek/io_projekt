var searchData=
[
  ['build_5fsession_5foption_0',['build_session_option',['../namespacemain.html#a6d5062e37acb11a5cfc7b8795d87e3e6',1,'main']]],
  ['build_5fsessions_5ffor_5flecturer_1',['build_sessions_for_lecturer',['../namespacemain.html#a304d0084956ddcec28adbcbe29d8813f',1,'main']]]
];
