var searchData=
[
  ['🦮_20license_0',['🦮 LICENSE',['../dir_e50ad3350d68b96628fd2070cabfbc61.html#autotoc_md42',1,'']]]
];
