var searchData=
[
  ['v_20plugin_20react_20svg_20https_3a_20npmjs_20com_20package_20plugin_20react_0',['@vitejs/plugin-react [![npm](&lt;a href=&quot;https://img.shields.io/npm/v/@vitejs/plugin-react.svg&quot;&gt;https://img.shields.io/npm/v/@vitejs/plugin-react.svg&lt;/a&gt;)](&lt;a href=&quot;https://npmjs.com/package/@vitejs/plugin-react&quot;&gt;https://npmjs.com/package/@vitejs/plugin-react&lt;/a&gt;)',['../dir_2d19b59ce45e013053da90327eef1ab1.html#autotoc_md14',1,'']]],
  ['v_20pluginutils_20svg_20https_3a_20npmx_20dev_20package_20pluginutils_1',['@rolldown/pluginutils [![npm](&lt;a href=&quot;https://img.shields.io/npm/v/@rolldown/pluginutils.svg&quot;&gt;https://img.shields.io/npm/v/@rolldown/pluginutils.svg&lt;/a&gt;)](&lt;a href=&quot;https://npmx.dev/package/@rolldown/pluginutils&quot;&gt;https://npmx.dev/package/@rolldown/pluginutils&lt;/a&gt;)',['../dir_65abdaaea5a1b6ecb7a775ec53a1dab8.html#autotoc_md2',1,'']]],
  ['validation_20middleware_2',['host-validation-middleware',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md215',1,'']]],
  ['value_20parser_3',['postcss-value-parser',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md282',1,'']]],
  ['values_4',['postcss-modules-values',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md278',1,'']]],
  ['vars_20pluginutils_5',['@rollup/plugin-alias, @rollup/plugin-dynamic-import-vars, @rollup/pluginutils',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md160',1,'']]],
  ['vary_6',['vary',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md308',1,'']]],
  ['version_7',['version',['../dir_db987a62e8987a103163524e89b0126d.html#autotoc_md31',1,'']]],
  ['versionsync_8',['versionSync',['../dir_db987a62e8987a103163524e89b0126d.html#autotoc_md32',1,'']]],
  ['vite_20⚡_9',['Vite ⚡',['../dir_1da6287cdf9906646d37bc082a2ddfe9.html#autotoc_md311',1,'']]],
  ['vite_20core_20license_10',['Vite core license',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html',1,'']]],
  ['vs_20bash_11',['Matching behavior vs. Bash',['../dir_7a583677d98b93c95bf092b149de9207.html#autotoc_md76',1,'']]]
];
