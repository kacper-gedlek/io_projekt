var searchData=
[
  ['koniec_0',['koniec',['../namespacerfid__reader.html#aeb1ef51a30101c69e9e0b7000f764fe8',1,'rfid_reader']]]
];
