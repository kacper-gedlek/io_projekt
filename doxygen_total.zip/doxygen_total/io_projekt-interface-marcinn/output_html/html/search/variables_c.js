var searchData=
[
  ['uid_0',['uid',['../namespacerfid__reader.html#a0ee9c1c7b403c20254bbd5fc12278c2b',1,'rfid_reader']]],
  ['uid_5fstr_1',['uid_str',['../namespacerfid__reader.html#a20fef6e6f28543dde6b2b38b97cd6776',1,'rfid_reader']]]
];
