var searchData=
[
  ['is_5fsession_5ffinished_0',['is_session_finished',['../namespacemain.html#a958037d917885ef58f8a31c4e796d1c8',1,'main']]]
];
