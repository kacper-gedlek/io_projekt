var searchData=
[
  ['key_20shebang_20regex_0',['path-key, shebang-regex',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md260',1,'']]],
  ['koniec_1',['koniec',['../namespacerfid__reader.html#aeb1ef51a30101c69e9e0b7000f764fe8',1,'rfid_reader']]],
  ['kontynuuj_2',['kontynuuj',['../namespacerfid__reader.html#aab80c5c0eae4b561ba526f8387178556',1,'rfid_reader']]]
];
