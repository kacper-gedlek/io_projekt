var searchData=
[
  ['response_0',['response',['../namespacerfid__reader.html#ab5658303b6b4c8eae27d4361d63f965f',1,'rfid_reader']]],
  ['room_5fname_1',['ROOM_NAME',['../namespacemain.html#aedd9214fafb4da45783aec997859f5fc',1,'main']]]
];
