var searchData=
[
  ['dane_0',['dane',['../namespacerfid__reader.html#a8ca238a8508839be7fc48a8eca187d7f',1,'rfid_reader']]]
];
