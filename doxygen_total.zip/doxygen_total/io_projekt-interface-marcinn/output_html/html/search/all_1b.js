var searchData=
[
  ['z_20serwerem_20moodle_0',['1. Architektura integracji z serwerem Moodle',['../baza_danych.html#moodle_sec',1,'']]],
  ['zdarzeń_20obecności_1',['3. Rejestracja zdarzeń obecności',['../baza_danych.html#logowanie',1,'']]],
  ['zero_20touch_20attendance_2',['Oficjalna Dokumentacja Systemu: Zero-TOUCH Attendance',['../index.html',1,'']]],
  ['zmiany_3',['Zmiany',['../md__r_e_a_d_m_e.html#autotoc_md313',1,'']]],
  ['zwj_20mit_20license_4',['&lt;blockquote class=&quot;doxtable&quot;&gt;
&lt;p&gt;MIT License&lt;/p&gt;
&lt;/blockquote&gt;
',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md199',1,'']]]
];
