var searchData=
[
  ['normalize_5fuid_0',['normalize_uid',['../namespacemain.html#a11007270d9c9b4ef35130ae76b65f56d',1,'main.normalize_uid()'],['../namespacerfid__reader.html#a8fe049e5606e2474dabf67455b4977e2',1,'rfid_reader.normalize_uid()']]]
];
