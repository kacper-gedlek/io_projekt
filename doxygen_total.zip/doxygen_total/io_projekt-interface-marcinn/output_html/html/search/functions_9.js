var searchData=
[
  ['moodle_5fget_0',['moodle_get',['../namespacemain.html#a617c413fded29210409d68b43580bdb5',1,'main']]],
  ['moodle_5fpost_1',['moodle_post',['../namespacemain.html#a9cb915a2b2dada1688ad7dbe94d1a32d',1,'main']]]
];
