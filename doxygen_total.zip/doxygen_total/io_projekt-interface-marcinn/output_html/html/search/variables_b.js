var searchData=
[
  ['teacher_5fauth_0',['teacher_auth',['../namespacemain.html#a1f29ae66809f4c901ad08b3da974cee4',1,'main']]],
  ['teraz_1',['teraz',['../namespacerfid__reader.html#a62027e82fef1a4ee694504732b7804f7',1,'rfid_reader']]]
];
