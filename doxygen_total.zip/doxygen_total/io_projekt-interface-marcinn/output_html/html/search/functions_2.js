var searchData=
[
  ['cancel_5fteacher_5fauth_0',['cancel_teacher_auth',['../namespacemain.html#afed885098eff2cf1aa2d3bdcd8b254db',1,'main']]],
  ['check_5fuser_5fby_5fcard_1',['check_user_by_card',['../namespacemain.html#a0dd026ce27ca31e3e5fedd5b9b9ac125',1,'main']]],
  ['clear_5fselected_5fcontext_2',['clear_selected_context',['../namespacemain.html#ae7ad418ceea829ce3bb3718b31d3c349',1,'main']]]
];
