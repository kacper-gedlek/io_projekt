var searchData=
[
  ['czytnik_0',['czytnik',['../namespacerfid__reader.html#a3b4025d21c9ac3193d5eb237de2acb1a',1,'rfid_reader']]]
];
