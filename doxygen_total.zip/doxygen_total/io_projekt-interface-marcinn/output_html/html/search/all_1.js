var searchData=
[
  ['2_20architektura_20systemu_20podział_20na_20moduły_0',['2. Architektura systemu (Podział na moduły)',['../index.html#arch_sec',1,'']]],
  ['2_20mapowanie_20sprzętowe_20tagów_20rfid_1',['2. Mapowanie Sprzętowe tagów RFID',['../baza_danych.html#mapowanie',1,'']]]
];
