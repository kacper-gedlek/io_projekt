var searchData=
[
  ['1_20architektura_20integracji_20z_20serwerem_20moodle_0',['1. Architektura integracji z serwerem Moodle',['../baza_danych.html#moodle_sec',1,'']]],
  ['1_20o_20projekcie_1',['1. O projekcie',['../index.html#intro_sec',1,'']]]
];
