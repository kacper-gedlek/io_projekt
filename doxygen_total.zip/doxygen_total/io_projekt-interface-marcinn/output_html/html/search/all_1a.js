var searchData=
[
  ['x64_20msvc_0',['`@rolldown/binding-win32-x64-msvc`',['../dir_27217b3a24722620152cbcb685d066e8.html#autotoc_md1',1,'']]]
];
