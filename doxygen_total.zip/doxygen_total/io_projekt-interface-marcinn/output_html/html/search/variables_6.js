var searchData=
[
  ['moodle_5fapi_5fkey_0',['MOODLE_API_KEY',['../namespacemain.html#a80035398fbd90df6fcb6185506d40f6e',1,'main']]],
  ['moodle_5fapi_5furl_1',['MOODLE_API_URL',['../namespacemain.html#ac8df4fda91157e01e651dd91cd11797d',1,'main']]]
];
