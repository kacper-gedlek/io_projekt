var searchData=
[
  ['kontynuuj_0',['kontynuuj',['../namespacerfid__reader.html#aab80c5c0eae4b561ba526f8387178556',1,'rfid_reader']]]
];
