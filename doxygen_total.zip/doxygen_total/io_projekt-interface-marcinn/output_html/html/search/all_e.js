var searchData=
[
  ['last_5fscan_0',['last_scan',['../namespacemain.html#a0913d72a6484399babecb5874a011106',1,'main']]],
  ['launch_20editor_20launch_20editor_20middleware_1',['launch-editor, launch-editor-middleware',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md231',1,'']]],
  ['launch_20editor_20middleware_2',['launch-editor, launch-editor-middleware',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md231',1,'']]],
  ['lazy_20prop_20is_20docker_20is_20inside_20container_20is_20wsl_20open_20run_20applescript_20wsl_20utils_3',['bundle-name, default-browser, default-browser-id, define-lazy-prop, is-docker, is-inside-container, is-wsl, open, run-applescript, wsl-utils',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md174',1,'']]],
  ['lessoninfo_2ejsx_4',['LessonInfo.jsx',['../_lesson_info_8jsx.html',1,'']]],
  ['level_20api_5',['level API',['../dir_e383ee6c920e4f5c6647b8cd409a80b8.html#autotoc_md116',1,'With SourceMapGenerator (low level API)'],['../dir_e383ee6c920e4f5c6647b8cd409a80b8.html#autotoc_md115',1,'With SourceNode (high level API)']]],
  ['lexer_6',['es-module-lexer',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md198',1,'']]],
  ['libc_7',['detect-libc',['../dir_db987a62e8987a103163524e89b0126d.html#autotoc_md24',1,'']]],
  ['library_20comparisons_8',['Library Comparisons',['../dir_7a583677d98b93c95bf092b149de9207.html#autotoc_md82',1,'']]],
  ['license_9',['🦮 LICENSE',['../dir_e50ad3350d68b96628fd2070cabfbc61.html#autotoc_md42',1,'']]],
  ['license_10',['License',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md199',1,'&lt;blockquote class=&quot;doxtable&quot;&gt;
&lt;p&gt;MIT License&lt;/p&gt;
&lt;/blockquote&gt;
'],['../dir_65abdaaea5a1b6ecb7a775ec53a1dab8.html#autotoc_md13',1,'License'],['../dir_7a583677d98b93c95bf092b149de9207.html#autotoc_md87',1,'License']]],
  ['license_11',['Vite core license',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html',1,'']]],
  ['license_2emd_12',['LICENSE.md',['../_l_i_c_e_n_s_e_8md.html',1,'']]],
  ['licenses_20of_20bundled_20dependencies_13',['Licenses of bundled dependencies',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md150',1,'']]],
  ['licensing_14',['Licensing',['../dir_db987a62e8987a103163524e89b0126d.html#autotoc_md35',1,'']]],
  ['lightning_20css_15',['⚡️ Lightning CSS',['../dir_dc6baa7e0a7f820dffdf3cbb90d95bb6.html#autotoc_md43',1,'']]],
  ['lilconfig_16',['lilconfig',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md233',1,'']]],
  ['line_20column_20source_20chunk_20name_17',['new SourceNode([line, column, source[, chunk[, name]]])',['../dir_e383ee6c920e4f5c6647b8cd409a80b8.html#autotoc_md135',1,'']]],
  ['literal_18',['strip-literal',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md298',1,'']]],
  ['literals_19',['Matching special characters as literals',['../dir_7a583677d98b93c95bf092b149de9207.html#autotoc_md81',1,'']]],
  ['load_20config_20',['postcss-load-config',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md268',1,'']]],
  ['loader_20utils_21',['loader-utils',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md235',1,'']]],
  ['local_20by_20default_22',['postcss-modules-local-by-default',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md274',1,'']]],
  ['lodash_20camelcase_23',['lodash.camelcase',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md237',1,'']]],
  ['logopanel_2ejsx_24',['LogoPanel.jsx',['../_logo_panel_8jsx.html',1,'']]],
  ['low_20level_20api_25',['With SourceMapGenerator (low level API)',['../dir_e383ee6c920e4f5c6647b8cd409a80b8.html#autotoc_md116',1,'']]]
];
