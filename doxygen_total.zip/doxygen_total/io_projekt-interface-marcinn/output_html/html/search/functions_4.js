var searchData=
[
  ['find_5fsession_5fby_5fid_0',['find_session_by_id',['../namespacemain.html#a5d066ac6a3a2650c863f0636a65582db',1,'main']]],
  ['format_5fsession_5fduration_1',['format_session_duration',['../namespacemain.html#a8571e01b3173bf2e1236e8a38b59f3b7',1,'main']]]
];
