var searchData=
[
  ['magic_20string_0',['magic-string',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md242',1,'']]],
  ['makeidfilterstomatchwithquery_1',['&lt;span class=&quot;tt&quot;&gt;makeIdFiltersToMatchWithQuery&lt;/span&gt;',['../dir_65abdaaea5a1b6ecb7a775ec53a1dab8.html#autotoc_md8',1,'']]],
  ['makere_2',['&lt;a href=&quot;lib/picomatch.js#L285&quot;&gt;.makeRe&lt;/a&gt;',['../dir_7a583677d98b93c95bf092b149de9207.html#autotoc_md63',1,'']]],
  ['map_3',['map',['../dir_e383ee6c920e4f5c6647b8cd409a80b8.html#autotoc_md113',1,'Consuming a source map'],['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md182',1,'convert-source-map'],['../dir_e383ee6c920e4f5c6647b8cd409a80b8.html#autotoc_md114',1,'Generating a source map']]],
  ['map_20js_4',['Source Map JS',['../dir_e383ee6c920e4f5c6647b8cd409a80b8.html#autotoc_md108',1,'']]],
  ['mapowanie_20sprzętowe_20tagów_20rfid_5',['2. Mapowanie Sprzętowe tagów RFID',['../baza_danych.html#mapowanie',1,'']]],
  ['mapping_6',['mapping',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md152',1,'@jridgewell/gen-mapping, @jridgewell/remapping, @jridgewell/sourcemap-codec, @jridgewell/trace-mapping'],['../dir_e383ee6c920e4f5c6647b8cd409a80b8.html#autotoc_md130',1,'SourceMapGenerator.prototype.addMapping(mapping)']]],
  ['mapping_20remapping_20sourcemap_20codec_20trace_20mapping_7',['@jridgewell/gen-mapping, @jridgewell/remapping, @jridgewell/sourcemap-codec, @jridgewell/trace-mapping',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md152',1,'']]],
  ['matchbase_8',['&lt;a href=&quot;lib/picomatch.js#L160&quot;&gt;.matchBase&lt;/a&gt;',['../dir_7a583677d98b93c95bf092b149de9207.html#autotoc_md58',1,'']]],
  ['matching_20behavior_20vs_20bash_9',['Matching behavior vs. Bash',['../dir_7a583677d98b93c95bf092b149de9207.html#autotoc_md76',1,'']]],
  ['matching_20special_20characters_20as_20literals_10',['Matching special characters as literals',['../dir_7a583677d98b93c95bf092b149de9207.html#autotoc_md81',1,'']]],
  ['merge_11',['utils-merge',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md306',1,'']]],
  ['middleware_12',['middleware',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md215',1,'host-validation-middleware'],['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md231',1,'launch-editor, launch-editor-middleware']]],
  ['mit_20license_13',['&lt;blockquote class=&quot;doxtable&quot;&gt;
&lt;p&gt;MIT License&lt;/p&gt;
&lt;/blockquote&gt;
',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md199',1,'']]],
  ['mlly_20ufo_14',['mlly, ufo',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md244',1,'']]],
  ['moduły_15',['2. Architektura systemu (Podział na moduły)',['../index.html#arch_sec',1,'']]],
  ['module_20lexer_16',['es-module-lexer',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md198',1,'']]],
  ['modules_17',['postcss-modules',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md270',1,'']]],
  ['modules_20extract_20imports_18',['postcss-modules-extract-imports',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md272',1,'']]],
  ['modules_20local_20by_20default_19',['postcss-modules-local-by-default',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md274',1,'']]],
  ['modules_20scope_20',['postcss-modules-scope',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md276',1,'']]],
  ['modules_20values_21',['postcss-modules-values',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md278',1,'']]],
  ['moodle_22',['1. Architektura integracji z serwerem Moodle',['../baza_danych.html#moodle_sec',1,'']]],
  ['mrmime_23',['mrmime',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md246',1,'']]],
  ['msvc_24',['`@rolldown/binding-win32-x64-msvc`',['../dir_27217b3a24722620152cbcb685d066e8.html#autotoc_md1',1,'']]],
  ['musl_25',['MUSL',['../dir_db987a62e8987a103163524e89b0126d.html#autotoc_md28',1,'']]]
];
