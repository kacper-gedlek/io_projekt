var searchData=
[
  ['key_20shebang_20regex_0',['path-key, shebang-regex',['../md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md260',1,'']]]
];
