var searchData=
[
  ['scan_5fcooldown_5fseconds_0',['SCAN_COOLDOWN_SECONDS',['../namespacemain.html#a2fd7e9042c954e00d5ac296cb942a981',1,'main']]],
  ['scan_5fdelay_5fseconds_1',['SCAN_DELAY_SECONDS',['../namespacerfid__reader.html#a458479a534f84ed4d7ac11893a0a6176',1,'rfid_reader']]],
  ['selected_5fcontext_2',['selected_context',['../namespacemain.html#a91668b14ec5faf58cc6c73573dbf2507',1,'main']]],
  ['status_3',['status',['../namespacerfid__reader.html#ab666e0798d5d4c0783458e1dcf45c832',1,'rfid_reader']]]
];
