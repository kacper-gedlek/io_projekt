var searchData=
[
  ['register_5fattendance_0',['register_attendance',['../namespacemain.html#aaae24e4e2db72a8757c2dacba518a0f8',1,'main']]],
  ['root_1',['root',['../namespacemain.html#acad80dd831ef8fb0a30fa217fadbfb36',1,'main']]]
];
