var dir_11d9d79f71a6415a24dc0b39d4cfe877 =
[
    [ "node_modules", "dir_a7f527d7d448ea48881e8c7864ce4b6e.html", "dir_a7f527d7d448ea48881e8c7864ce4b6e" ],
    [ "main.py", "main_8py.html", "main_8py" ],
    [ "rfid_reader.py", "rfid__reader_8py.html", "rfid__reader_8py" ]
];