/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Zero-TOUCH Attendance System - Interfejs", "index.html", [
    [ "Oficjalna Dokumentacja Systemu: Zero-TOUCH Attendance", "index.html", "index" ],
    [ "Vite core license", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html", [
      [ "Licenses of bundled dependencies", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md150", null ],
      [ "Bundled dependencies:", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md151", [
        [ "@jridgewell/gen-mapping, @jridgewell/remapping, @jridgewell/sourcemap-codec, @jridgewell/trace-mapping", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md152", null ],
        [ "@jridgewell/resolve-uri", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md154", null ],
        [ "@polka/compression", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md156", null ],
        [ "@polka/url", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md158", null ],
        [ "@rollup/plugin-alias, @rollup/plugin-dynamic-import-vars, @rollup/pluginutils", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md160", null ],
        [ "@vercel/detect-agent", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md162", null ],
        [ "@vitest/utils", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md164", null ],
        [ "anymatch", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md166", null ],
        [ "artichokie", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md168", null ],
        [ "binary-extensions", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md170", null ],
        [ "braces, fill-range, is-number", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md172", null ],
        [ "bundle-name, default-browser, default-browser-id, define-lazy-prop, is-docker, is-inside-container, is-wsl, open, run-applescript, wsl-utils", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md174", null ],
        [ "cac", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md176", null ],
        [ "chokidar", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md178", null ],
        [ "connect", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md180", null ],
        [ "convert-source-map", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md182", null ],
        [ "cors", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md184", null ],
        [ "cross-spawn", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md186", null ],
        [ "cssesc", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md188", null ],
        [ "dotenv-expand", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md190", null ],
        [ "ee-first", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md192", null ],
        [ "encodeurl", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md194", null ],
        [ "entities", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md196", null ],
        [ "es-module-lexer", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md198", null ],
        [ "<blockquote class=\"doxtable\">
<p>MIT License</p>
</blockquote>
", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md199", null ],
        [ "escape-html", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md201", null ],
        [ "estree-walker", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md203", null ],
        [ "etag", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md205", null ],
        [ "finalhandler", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md207", null ],
        [ "follow-redirects", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md209", null ],
        [ "generic-names", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md211", null ],
        [ "glob-parent", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md213", null ],
        [ "host-validation-middleware", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md215", null ],
        [ "http-proxy-3", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md217", null ],
        [ "icss-utils", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md219", null ],
        [ "is-binary-path", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md221", null ],
        [ "is-extglob", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md223", null ],
        [ "is-glob", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md225", null ],
        [ "isexe, which", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md227", null ],
        [ "js-tokens", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md229", null ],
        [ "launch-editor, launch-editor-middleware", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md231", null ],
        [ "lilconfig", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md233", null ],
        [ "loader-utils", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md235", null ],
        [ "lodash.camelcase", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md237", null ],
        [ "magic-string", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md242", null ],
        [ "mlly, ufo", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md244", null ],
        [ "mrmime", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md246", null ],
        [ "normalize-path", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md248", null ],
        [ "object-assign", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md250", null ],
        [ "obug", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md252", null ],
        [ "on-finished", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md254", null ],
        [ "parse5", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md256", null ],
        [ "parseurl", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md258", null ],
        [ "path-key, shebang-regex", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md260", null ],
        [ "periscopic", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md262", null ],
        [ "picocolors", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md264", null ],
        [ "postcss-import", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md266", null ],
        [ "postcss-load-config", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md268", null ],
        [ "postcss-modules", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md270", null ],
        [ "postcss-modules-extract-imports", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md272", null ],
        [ "postcss-modules-local-by-default", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md274", null ],
        [ "postcss-modules-scope", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md276", null ],
        [ "postcss-modules-values", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md278", null ],
        [ "postcss-selector-parser", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md280", null ],
        [ "postcss-value-parser", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md282", null ],
        [ "readdirp", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md284", null ],
        [ "resolve.exports, totalist", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md286", null ],
        [ "shebang-command", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md288", null ],
        [ "shell-quote", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md290", null ],
        [ "sirv", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md292", null ],
        [ "statuses", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md294", null ],
        [ "string-hash", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md296", null ],
        [ "strip-literal", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md298", null ],
        [ "to-regex-range", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md300", null ],
        [ "unpipe", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md302", null ],
        [ "util-deprecate", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md304", null ],
        [ "utils-merge", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md306", null ],
        [ "vary", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md308", null ],
        [ "ws", "md_node__modules_2vite_2_l_i_c_e_n_s_e.html#autotoc_md310", null ]
      ] ]
    ] ],
    [ "POLS Dashboard Frontend", "md__r_e_a_d_m_e.html", [
      [ "Zmiany", "md__r_e_a_d_m_e.html#autotoc_md313", null ],
      [ "Uruchomienie", "md__r_e_a_d_m_e.html#autotoc_md314", null ]
    ] ],
    [ "Packages", "namespaces.html", [
      [ "Package List", "namespaces.html", "namespaces_dup" ],
      [ "Package Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ],
        [ "Variables", "namespacemembers_vars.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_app_8jsx.html"
];

var SYNCONMSG = 'click to disable panel synchronization';
var SYNCOFFMSG = 'click to enable panel synchronization';
var LISTOFALLMEMBERS = 'List of all members';