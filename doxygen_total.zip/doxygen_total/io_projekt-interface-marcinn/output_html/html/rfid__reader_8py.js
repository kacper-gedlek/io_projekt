var rfid__reader_8py =
[
    [ "rfid_reader.koniec", "namespacerfid__reader.html#aeb1ef51a30101c69e9e0b7000f764fe8", null ],
    [ "rfid_reader.normalize_uid", "namespacerfid__reader.html#a8fe049e5606e2474dabf67455b4977e2", null ],
    [ "rfid_reader.API_URL", "namespacerfid__reader.html#ad232108029960e2f6e1de932ba1c0445", null ],
    [ "rfid_reader.czytnik", "namespacerfid__reader.html#a3b4025d21c9ac3193d5eb237de2acb1a", null ],
    [ "rfid_reader.dane", "namespacerfid__reader.html#a8ca238a8508839be7fc48a8eca187d7f", null ],
    [ "rfid_reader.kontynuuj", "namespacerfid__reader.html#aab80c5c0eae4b561ba526f8387178556", null ],
    [ "rfid_reader.ostatni_czas", "namespacerfid__reader.html#a45f751a339e60d2ddf28166dcd308d54", null ],
    [ "rfid_reader.ostatni_uid", "namespacerfid__reader.html#a7fded2a89ce6a3a3cd220d0293d2d434", null ],
    [ "rfid_reader.response", "namespacerfid__reader.html#ab5658303b6b4c8eae27d4361d63f965f", null ],
    [ "rfid_reader.SCAN_DELAY_SECONDS", "namespacerfid__reader.html#a458479a534f84ed4d7ac11893a0a6176", null ],
    [ "rfid_reader.status", "namespacerfid__reader.html#ab666e0798d5d4c0783458e1dcf45c832", null ],
    [ "rfid_reader.teraz", "namespacerfid__reader.html#a62027e82fef1a4ee694504732b7804f7", null ],
    [ "rfid_reader.uid", "namespacerfid__reader.html#a0ee9c1c7b403c20254bbd5fc12278c2b", null ],
    [ "rfid_reader.uid_str", "namespacerfid__reader.html#a20fef6e6f28543dde6b2b38b97cd6776", null ]
];