var dir_a7f527d7d448ea48881e8c7864ce4b6e =
[
    [ "@oxc-project", "dir_b0fe015c388de4f54b72e87f314c7ef7.html", "dir_b0fe015c388de4f54b72e87f314c7ef7" ],
    [ "@rolldown", "dir_74745d7835740335ce3d5f57e8f1183b.html", "dir_74745d7835740335ce3d5f57e8f1183b" ],
    [ "@vitejs", "dir_4d8e60e973cd738629e805646dbdcc73.html", "dir_4d8e60e973cd738629e805646dbdcc73" ],
    [ "detect-libc", "dir_8e1063ad7a8483b24ca1974c63cb1a4c.html", null ],
    [ "fdir", "dir_17c9cf4483498814888cea46381709fa.html", null ],
    [ "lightningcss", "dir_3be8b032e4c81a933bd511737b73b4d9.html", null ],
    [ "lightningcss-win32-x64-msvc", "dir_86c0b30792644749f3a7510fe65db6ee.html", null ],
    [ "nanoid", "dir_46f955c297589a905aaeb078ba556c37.html", null ],
    [ "picocolors", "dir_3fbffc55adc0771bf0dedf3912bca8e7.html", null ],
    [ "picomatch", "dir_5c3bc97645f31ec9b0dd557b2cb1ac4f.html", null ],
    [ "postcss", "dir_526469892d64c88465848c04854987c2.html", null ],
    [ "react", "dir_9b312926189bc8846eef157c6b455554.html", null ],
    [ "react-dom", "dir_c9179c9c0de1c78dc355be7a99ac2bd9.html", null ],
    [ "rolldown", "dir_f49eb8ee8d97b539d423bf0a7873997e.html", null ],
    [ "scheduler", "dir_95067f296f3460fac4b085d401faca57.html", null ],
    [ "source-map-js", "dir_4cd2e5b0e276dafbaf5c6060f178b7bb.html", null ],
    [ "tinyglobby", "dir_1bf5aded5fdff7baba62b0612f344133.html", null ],
    [ "vite", "dir_90a0e20bdedea6fb810db933e07250c1.html", null ]
];