var index =
[
    [ "1. O projekcie", "index.html#intro_sec", null ],
    [ "2. Architektura systemu (Podział na moduły)", "index.html#arch_sec", null ],
    [ "3. Nawigacja i Baza Danych", "index.html#links_sec", null ],
    [ "Dokumentacja Struktury Bazy Danych", "baza_danych.html", [
      [ "1. Architektura integracji z serwerem Moodle", "baza_danych.html#moodle_sec", null ],
      [ "2. Mapowanie Sprzętowe tagów RFID", "baza_danych.html#mapowanie", null ],
      [ "3. Rejestracja zdarzeń obecności", "baza_danych.html#logowanie", null ]
    ] ]
];