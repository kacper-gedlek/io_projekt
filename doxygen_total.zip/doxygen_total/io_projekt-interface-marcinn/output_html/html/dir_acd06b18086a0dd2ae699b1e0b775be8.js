var dir_acd06b18086a0dd2ae699b1e0b775be8 =
[
    [ "@oxc-project", "dir_3f5710335a76839a4cd2774372b6b8aa.html", "dir_3f5710335a76839a4cd2774372b6b8aa" ],
    [ "@rolldown", "dir_552f80d657beea6d3dd748b213cdb94f.html", "dir_552f80d657beea6d3dd748b213cdb94f" ],
    [ "@vitejs", "dir_1a185a8de7ca714ce8c15be35dbfffaa.html", "dir_1a185a8de7ca714ce8c15be35dbfffaa" ],
    [ "detect-libc", "dir_db987a62e8987a103163524e89b0126d.html", null ],
    [ "fdir", "dir_e50ad3350d68b96628fd2070cabfbc61.html", null ],
    [ "lightningcss", "dir_dc6baa7e0a7f820dffdf3cbb90d95bb6.html", null ],
    [ "lightningcss-win32-x64-msvc", "dir_4626812782e2448d80791638753f1563.html", null ],
    [ "nanoid", "dir_dbff3518ccac0079db1f76108e8705d6.html", null ],
    [ "picocolors", "dir_dba109dbb2d6cba37e3a183f2348d522.html", null ],
    [ "picomatch", "dir_7a583677d98b93c95bf092b149de9207.html", null ],
    [ "postcss", "dir_89573d253c39d404d6de30837b232e6f.html", null ],
    [ "react", "dir_c482761834072f124f8df279fc01880d.html", null ],
    [ "react-dom", "dir_ca5928ce57d942246ce529d4df3ccdc3.html", null ],
    [ "rolldown", "dir_6eeea5982b6bda9ac20383edb6120e9d.html", null ],
    [ "scheduler", "dir_2e599a387e5b6f25881c92f246dbec7e.html", null ],
    [ "source-map-js", "dir_e383ee6c920e4f5c6647b8cd409a80b8.html", null ],
    [ "tinyglobby", "dir_beac8c269e2846520146594ffb24b502.html", null ],
    [ "vite", "dir_1da6287cdf9906646d37bc082a2ddfe9.html", null ]
];