var searchData=
[
  ['ważne_20linki_3a_0',['Ważne linki:',['../md__r_e_a_d_m_e.html#autotoc_md1',1,'']]]
];
