var searchData=
[
  ['plików_20ignorowanych_20przez_3a_0',['Lista plików ignorowanych przez:',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]],
  ['port_1',['port',['../namespacemain.html#a12fac67ac230690557ab76d3faa71d8c',1,'main']]],
  ['przez_3a_2',['Lista plików ignorowanych przez:',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]]
];
