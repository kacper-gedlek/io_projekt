var searchData=
[
  ['linki_3a_0',['Ważne linki:',['../md__r_e_a_d_m_e.html#autotoc_md1',1,'']]],
  ['lista_20plików_20ignorowanych_20przez_3a_1',['Lista plików ignorowanych przez:',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]]
];
