var searchData=
[
  ['danych_0',['Dokumentacja Struktury Bazy Danych',['../baza_danych.html',1,'']]],
  ['dokumentacja_20struktury_20bazy_20danych_1',['Dokumentacja Struktury Bazy Danych',['../baza_danych.html',1,'']]],
  ['dokumentacja_3a_2',['Dokumentacja:',['../md__r_e_a_d_m_e.html#autotoc_md3',1,'']]]
];
