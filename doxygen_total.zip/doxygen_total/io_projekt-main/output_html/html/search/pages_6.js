var searchData=
[
  ['ignorowanych_20przez_3a_0',['Lista plików ignorowanych przez:',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]],
  ['integracji_20z_20serwerem_20moodle_1',['1. Architektura integracji z serwerem Moodle',['../baza_danych.html#moodle_sec',1,'']]],
  ['io_5fprojekt_2',['io_projekt',['../md__r_e_a_d_m_e.html',1,'']]]
];
