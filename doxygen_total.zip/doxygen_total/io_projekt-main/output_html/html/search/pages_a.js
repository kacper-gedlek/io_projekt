var searchData=
[
  ['plików_20ignorowanych_20przez_3a_0',['Lista plików ignorowanych przez:',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]],
  ['przez_3a_1',['Lista plików ignorowanych przez:',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]]
];
