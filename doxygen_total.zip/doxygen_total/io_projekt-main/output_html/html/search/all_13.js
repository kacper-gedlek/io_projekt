var searchData=
[
  ['user_0',['User',['../classdatabase_1_1_user.html',1,'database']]],
  ['username_1',['username',['../classdatabase_1_1_user.html#a5f4e040350b16bb0e87871cde5bed9bc',1,'database::User']]]
];
