var namespaces_dup =
[
    [ "database", "namespacedatabase.html", "namespacedatabase" ],
    [ "main", "namespacemain.html", [
      [ "get_db", "namespacemain.html#a153c51f50728eed3c7634b654ce959f1", null ],
      [ "get_user_courses", "namespacemain.html#aad7ebf49635c8c44f73d1c8ff11c2b42", null ],
      [ "read_user", "namespacemain.html#ab589e0e79c6e2dfc849ccd85763bcef9", null ],
      [ "test_db", "namespacemain.html#a3e573eb35ddf2cfe8f5eaaabd44ebb18", null ],
      [ "app", "namespacemain.html#a5fa94f0581009434c7a63791944d6ff4", null ],
      [ "host", "namespacemain.html#a0cf58d9b4a444874a8cf80fdf162b0fb", null ],
      [ "port", "namespacemain.html#a12fac67ac230690557ab76d3faa71d8c", null ]
    ] ]
];