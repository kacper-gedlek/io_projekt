var files_dup =
[
    [ "database.py", "database_8py.html", "database_8py" ],
    [ "main.py", "main_8py.html", "main_8py" ]
];