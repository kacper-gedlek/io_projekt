var hierarchy =
[
    [ "Base", null, [
      [ "database.Course", "classdatabase_1_1_course.html", null ],
      [ "database.User", "classdatabase_1_1_user.html", null ]
    ] ]
];