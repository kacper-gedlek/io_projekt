var searchData=
[
  ['get_5fdb_0',['get_db',['../namespacemain.html#a153c51f50728eed3c7634b654ce959f1',1,'main']]],
  ['get_5fuser_5fcourses_1',['get_user_courses',['../namespacemain.html#aad7ebf49635c8c44f73d1c8ff11c2b42',1,'main']]]
];
