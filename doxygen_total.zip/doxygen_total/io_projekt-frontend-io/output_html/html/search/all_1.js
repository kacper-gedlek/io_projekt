var searchData=
[
  ['2_20mapowanie_20sprzętowe_20tagów_20rfid_0',['2. Mapowanie Sprzętowe tagów RFID',['../baza_danych.html#mapowanie',1,'']]]
];
