var searchData=
[
  ['tagów_20rfid_0',['2. Mapowanie Sprzętowe tagów RFID',['../baza_danych.html#mapowanie',1,'']]],
  ['test_5fdb_1',['test_db',['../namespacemain.html#a3e573eb35ddf2cfe8f5eaaabd44ebb18',1,'main']]]
];
