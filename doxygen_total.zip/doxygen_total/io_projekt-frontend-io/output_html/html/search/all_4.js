var searchData=
[
  ['base_0',['Base',['../namespacedatabase.html#a0a351bcdc86bdc97cd3c88759443bb4a',1,'database']]],
  ['bazy_20danych_1',['Dokumentacja Struktury Bazy Danych',['../baza_danych.html',1,'']]]
];
