var searchData=
[
  ['serwerem_20moodle_0',['1. Architektura integracji z serwerem Moodle',['../baza_danych.html#moodle_sec',1,'']]],
  ['sessionlocal_1',['SessionLocal',['../namespacedatabase.html#aa8b73386925fff9047c8961bb8d5de2a',1,'database']]],
  ['shortname_2',['shortname',['../classdatabase_1_1_course.html#af065a26ffff8b7cb936448e0fd04d591',1,'database::Course']]],
  ['sprzętowe_20tagów_20rfid_3',['2. Mapowanie Sprzętowe tagów RFID',['../baza_danych.html#mapowanie',1,'']]],
  ['struktury_20bazy_20danych_4',['Dokumentacja Struktury Bazy Danych',['../baza_danych.html',1,'']]],
  ['suspended_5',['suspended',['../classdatabase_1_1_user.html#a66082e6cc972f1fa56821459bd669b98',1,'database::User']]]
];
