var searchData=
[
  ['danych_0',['Dokumentacja Struktury Bazy Danych',['../baza_danych.html',1,'']]],
  ['dashboard_20frontend_1',['POLS Dashboard Frontend',['../md__r_e_a_d_m_e.html',1,'']]],
  ['database_2',['database',['../namespacedatabase.html',1,'']]],
  ['database_2edox_3',['database.dox',['../database_8dox.html',1,'']]],
  ['database_2epy_4',['database.py',['../database_8py.html',1,'']]],
  ['database_5furl_5',['DATABASE_URL',['../namespacedatabase.html#a20a7ed6071551ee951d19dcf03eb167f',1,'database']]],
  ['db_5fhost_6',['DB_HOST',['../namespacedatabase.html#ab53324858424978c1c2181bb11feb533',1,'database']]],
  ['db_5fname_7',['DB_NAME',['../namespacedatabase.html#a02f175f421082e4f6c92d2cd95952a53',1,'database']]],
  ['db_5fpassword_8',['DB_PASSWORD',['../namespacedatabase.html#ac95e705b93bf56d23c7ef8a783430677',1,'database']]],
  ['db_5fport_9',['DB_PORT',['../namespacedatabase.html#ae1eb64a337096b3021e1819fa94627c4',1,'database']]],
  ['db_5fuser_10',['DB_USER',['../namespacedatabase.html#aa50cf485f7373e2986ba89d8f6a43761',1,'database']]],
  ['department_11',['department',['../classdatabase_1_1_user.html#a283445e3059b9d9541b18b6f3dc69751',1,'database::User']]],
  ['dokumentacja_20struktury_20bazy_20danych_12',['Dokumentacja Struktury Bazy Danych',['../baza_danych.html',1,'']]]
];
