var searchData=
[
  ['firstname_0',['firstname',['../classdatabase_1_1_user.html#ad5e593b1735e7b433b88dde45874dc8c',1,'database::User']]],
  ['fullname_1',['fullname',['../classdatabase_1_1_course.html#aa5f5a767820695a8bdcca04102700f3a',1,'database::Course']]]
];
