var searchData=
[
  ['id_0',['id',['../classdatabase_1_1_user.html#af5b7c54bb80226bbdf6755ea201d5e7c',1,'database.User.id'],['../classdatabase_1_1_course.html#a9c727274a276f565c96ac4cf0f4bfaa7',1,'database.Course.id']]],
  ['integracji_20z_20serwerem_20moodle_1',['1. Architektura integracji z serwerem Moodle',['../baza_danych.html#moodle_sec',1,'']]]
];
