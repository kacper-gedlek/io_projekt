var searchData=
[
  ['app_0',['app',['../namespacemain.html#a5fa94f0581009434c7a63791944d6ff4',1,'main']]],
  ['architektura_20integracji_20z_20serwerem_20moodle_1',['1. Architektura integracji z serwerem Moodle',['../baza_danych.html#moodle_sec',1,'']]]
];
