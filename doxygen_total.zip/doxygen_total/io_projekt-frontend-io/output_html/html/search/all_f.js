var searchData=
[
  ['pols_20dashboard_20frontend_0',['POLS Dashboard Frontend',['../md__r_e_a_d_m_e.html',1,'']]],
  ['port_1',['port',['../namespacemain.html#a12fac67ac230690557ab76d3faa71d8c',1,'main']]]
];
