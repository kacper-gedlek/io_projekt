var searchData=
[
  ['bazy_20danych_0',['Dokumentacja Struktury Bazy Danych',['../baza_danych.html',1,'']]]
];
