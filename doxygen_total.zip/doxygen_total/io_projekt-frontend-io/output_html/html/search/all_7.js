var searchData=
[
  ['email_0',['email',['../classdatabase_1_1_user.html#aa08ad8e573a63b902f4426b7eca84249',1,'database::User']]],
  ['engine_1',['engine',['../namespacedatabase.html#a63bc446125e29d43241b8cf215258bcc',1,'database']]]
];
