var searchData=
[
  ['3_20rejestracja_20zdarzeń_20obecności_0',['3. Rejestracja zdarzeń obecności',['../baza_danych.html#logowanie',1,'']]]
];
