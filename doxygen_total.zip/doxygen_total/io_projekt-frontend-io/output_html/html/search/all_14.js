var searchData=
[
  ['z_20serwerem_20moodle_0',['1. Architektura integracji z serwerem Moodle',['../baza_danych.html#moodle_sec',1,'']]],
  ['zdarzeń_20obecności_1',['3. Rejestracja zdarzeń obecności',['../baza_danych.html#logowanie',1,'']]],
  ['zmiany_2',['Zmiany',['../md__r_e_a_d_m_e.html#autotoc_md1',1,'']]]
];
