var searchData=
[
  ['danych_0',['Dokumentacja Struktury Bazy Danych',['../baza_danych.html',1,'']]],
  ['dashboard_20frontend_1',['POLS Dashboard Frontend',['../md__r_e_a_d_m_e.html',1,'']]],
  ['dokumentacja_20struktury_20bazy_20danych_2',['Dokumentacja Struktury Bazy Danych',['../baza_danych.html',1,'']]]
];
