var searchData=
[
  ['serwerem_20moodle_0',['1. Architektura integracji z serwerem Moodle',['../baza_danych.html#moodle_sec',1,'']]],
  ['sprzętowe_20tagów_20rfid_1',['2. Mapowanie Sprzętowe tagów RFID',['../baza_danych.html#mapowanie',1,'']]],
  ['struktury_20bazy_20danych_2',['Dokumentacja Struktury Bazy Danych',['../baza_danych.html',1,'']]]
];
