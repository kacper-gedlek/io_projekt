var searchData=
[
  ['obecności_0',['3. Rejestracja zdarzeń obecności',['../baza_danych.html#logowanie',1,'']]]
];
