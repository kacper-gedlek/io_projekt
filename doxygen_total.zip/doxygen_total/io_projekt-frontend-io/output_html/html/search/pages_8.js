var searchData=
[
  ['mapowanie_20sprzętowe_20tagów_20rfid_0',['2. Mapowanie Sprzętowe tagów RFID',['../baza_danych.html#mapowanie',1,'']]],
  ['moodle_1',['1. Architektura integracji z serwerem Moodle',['../baza_danych.html#moodle_sec',1,'']]]
];
