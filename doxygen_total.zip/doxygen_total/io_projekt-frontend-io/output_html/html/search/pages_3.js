var searchData=
[
  ['architektura_20integracji_20z_20serwerem_20moodle_0',['1. Architektura integracji z serwerem Moodle',['../baza_danych.html#moodle_sec',1,'']]]
];
