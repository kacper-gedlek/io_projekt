var searchData=
[
  ['frontend_0',['POLS Dashboard Frontend',['../md__r_e_a_d_m_e.html',1,'']]]
];
