var searchData=
[
  ['username_0',['username',['../classdatabase_1_1_user.html#a5f4e040350b16bb0e87871cde5bed9bc',1,'database::User']]]
];
