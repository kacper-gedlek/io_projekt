var searchData=
[
  ['confirmed_0',['confirmed',['../classdatabase_1_1_user.html#aaceab48629cfc83690cb9d4808c162db',1,'database::User']]],
  ['course_1',['Course',['../classdatabase_1_1_course.html',1,'database']]]
];
