var indexSectionsWithContent =
{
  0: "123abcdefghilmoprstuz",
  1: "cu",
  2: "dm",
  3: "dmr",
  4: "grt",
  5: "abcdefhilpsu",
  6: "123abdfimoprstuz"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Pages"
};

