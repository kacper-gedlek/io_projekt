var searchData=
[
  ['rejestracja_20zdarzeń_20obecności_0',['3. Rejestracja zdarzeń obecności',['../baza_danych.html#logowanie',1,'']]],
  ['rfid_1',['2. Mapowanie Sprzętowe tagów RFID',['../baza_danych.html#mapowanie',1,'']]]
];
