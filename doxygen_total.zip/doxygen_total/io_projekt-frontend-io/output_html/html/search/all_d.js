var searchData=
[
  ['main_0',['main',['../namespacemain.html',1,'']]],
  ['main_2epy_1',['main.py',['../main_8py.html',1,'']]],
  ['mapowanie_20sprzętowe_20tagów_20rfid_2',['2. Mapowanie Sprzętowe tagów RFID',['../baza_danych.html#mapowanie',1,'']]],
  ['moodle_3',['1. Architektura integracji z serwerem Moodle',['../baza_danych.html#moodle_sec',1,'']]]
];
