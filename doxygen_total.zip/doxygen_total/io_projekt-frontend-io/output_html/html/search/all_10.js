var searchData=
[
  ['read_5fuser_0',['read_user',['../namespacemain.html#ab589e0e79c6e2dfc849ccd85763bcef9',1,'main']]],
  ['readme_2emd_1',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['rejestracja_20zdarzeń_20obecności_2',['3. Rejestracja zdarzeń obecności',['../baza_danych.html#logowanie',1,'']]],
  ['rfid_3',['2. Mapowanie Sprzętowe tagów RFID',['../baza_danych.html#mapowanie',1,'']]]
];
