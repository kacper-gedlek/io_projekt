var searchData=
[
  ['sessionlocal_0',['SessionLocal',['../namespacedatabase.html#aa8b73386925fff9047c8961bb8d5de2a',1,'database']]],
  ['shortname_1',['shortname',['../classdatabase_1_1_course.html#af065a26ffff8b7cb936448e0fd04d591',1,'database::Course']]],
  ['suspended_2',['suspended',['../classdatabase_1_1_user.html#a66082e6cc972f1fa56821459bd669b98',1,'database::User']]]
];
