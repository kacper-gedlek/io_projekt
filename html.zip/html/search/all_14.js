var searchData=
[
  ['ważne_20linki_3a_0',['Ważne linki:',['../dir_a5c0c88a8529b95de2cba028f3ae4742.html#autotoc_md1',1,'']]]
];
