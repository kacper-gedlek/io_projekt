var searchData=
[
  ['ignorowanych_20przez_3a_0',['Lista plików ignorowanych przez:',['../dir_a5c0c88a8529b95de2cba028f3ae4742.html#autotoc_md2',1,'']]],
  ['integracji_20z_20serwerem_20moodle_1',['1. Architektura integracji z serwerem Moodle',['../baza_danych.html#moodle_sec',1,'']]],
  ['io_5fprojekt_2',['io_projekt',['../dir_a5c0c88a8529b95de2cba028f3ae4742.html#autotoc_md0',1,'']]]
];
