var searchData=
[
  ['danych_0',['Dokumentacja Struktury Bazy Danych',['../baza_danych.html',1,'']]],
  ['dokumentacja_20struktury_20bazy_20danych_1',['Dokumentacja Struktury Bazy Danych',['../baza_danych.html',1,'']]],
  ['dokumentacja_3a_2',['Dokumentacja:',['../dir_a5c0c88a8529b95de2cba028f3ae4742.html#autotoc_md3',1,'']]]
];
