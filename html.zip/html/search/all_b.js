var searchData=
[
  ['id_0',['id',['../classdatabase_1_1_user.html#af5b7c54bb80226bbdf6755ea201d5e7c',1,'database::User']]],
  ['ignorowanych_20przez_3a_1',['Lista plików ignorowanych przez:',['../dir_a5c0c88a8529b95de2cba028f3ae4742.html#autotoc_md2',1,'']]],
  ['integracji_20z_20serwerem_20moodle_2',['1. Architektura integracji z serwerem Moodle',['../baza_danych.html#moodle_sec',1,'']]],
  ['io_5fprojekt_3',['io_projekt',['../dir_a5c0c88a8529b95de2cba028f3ae4742.html#autotoc_md0',1,'']]]
];
