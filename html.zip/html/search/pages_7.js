var searchData=
[
  ['linki_3a_0',['Ważne linki:',['../dir_a5c0c88a8529b95de2cba028f3ae4742.html#autotoc_md1',1,'']]],
  ['lista_20plików_20ignorowanych_20przez_3a_1',['Lista plików ignorowanych przez:',['../dir_a5c0c88a8529b95de2cba028f3ae4742.html#autotoc_md2',1,'']]]
];
