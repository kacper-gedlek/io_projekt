var searchData=
[
  ['plików_20ignorowanych_20przez_3a_0',['Lista plików ignorowanych przez:',['../dir_a5c0c88a8529b95de2cba028f3ae4742.html#autotoc_md2',1,'']]],
  ['przez_3a_1',['Lista plików ignorowanych przez:',['../dir_a5c0c88a8529b95de2cba028f3ae4742.html#autotoc_md2',1,'']]]
];
