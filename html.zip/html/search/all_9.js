var searchData=
[
  ['get_5fdb_0',['get_db',['../namespacemain.html#a153c51f50728eed3c7634b654ce959f1',1,'main']]]
];
