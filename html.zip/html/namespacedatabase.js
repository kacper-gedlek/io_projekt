var namespacedatabase =
[
    [ "User", "classdatabase_1_1_user.html", null ],
    [ "Base", "namespacedatabase.html#a0a351bcdc86bdc97cd3c88759443bb4a", null ],
    [ "DATABASE_URL", "namespacedatabase.html#a20a7ed6071551ee951d19dcf03eb167f", null ],
    [ "DB_HOST", "namespacedatabase.html#ab53324858424978c1c2181bb11feb533", null ],
    [ "DB_NAME", "namespacedatabase.html#a02f175f421082e4f6c92d2cd95952a53", null ],
    [ "DB_PASSWORD", "namespacedatabase.html#ac95e705b93bf56d23c7ef8a783430677", null ],
    [ "DB_PORT", "namespacedatabase.html#ae1eb64a337096b3021e1819fa94627c4", null ],
    [ "DB_USER", "namespacedatabase.html#aa50cf485f7373e2986ba89d8f6a43761", null ],
    [ "engine", "namespacedatabase.html#a63bc446125e29d43241b8cf215258bcc", null ],
    [ "SessionLocal", "namespacedatabase.html#aa8b73386925fff9047c8961bb8d5de2a", null ]
];