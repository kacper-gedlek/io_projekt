var hierarchy =
[
    [ "Base", null, [
      [ "database.User", "classdatabase_1_1_user.html", null ]
    ] ]
];