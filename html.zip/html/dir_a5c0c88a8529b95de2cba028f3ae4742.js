var dir_a5c0c88a8529b95de2cba028f3ae4742 =
[
    [ "database.py", "database_8py.html", "database_8py" ],
    [ "main.py", "main_8py.html", "main_8py" ]
];