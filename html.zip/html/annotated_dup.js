var annotated_dup =
[
    [ "database", "namespacedatabase.html", [
      [ "User", "classdatabase_1_1_user.html", null ]
    ] ]
];